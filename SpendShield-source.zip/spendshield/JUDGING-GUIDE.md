# SpendShield: presentation guide

## The product story

Most spending tools explain where money went. SpendShield helps a person understand the next purchase, compare it with a goal, make a decision, and distinguish an intention from money actually saved.

The central experience is a visible sequence: understand the purchase, calculate its consequence, compare another price, pause or choose, then confirm the savings. AI interprets descriptions and images; deterministic Python calculates financial results in cents.

## Three-minute walkthrough

Use a separate practice profile or backup your own profile before changing it for a presentation. Do not present invented transactions as someone's real finances.

1. **Personal context (30 seconds).** Show the name, discretionary budget and goal from setup. Explain that new profiles start empty. Add one transaction so the audience sees the numbers are editable records.
2. **A consequential purchase (60 seconds).** Enter an item priced at $160, or upload the included synthetic shopping image with Gemini enabled. Confirm the extracted price. Show the share of the budget and the goal delay, then expand the explanation of the calculation.
3. **A useful choice (40 seconds).** Compare $87 with $160. The dollar difference is $73; the time difference depends on the profile's contribution. Save a target/reminder or record a verified cheaper option. Be explicit that a web search is not a live price guarantee.
4. **An honest outcome (30 seconds).** Open Activity. Show planned savings, then Mark as saved after explaining that the user moves money themselves. Demonstrate Mark as not saved or Undo decision to show mistakes are recoverable.
5. **Trust and completeness (20 seconds).** Show category approval, backup preview/recovery and the in-app Guide. Mention the optional guard and local privacy controls.

## Technical points worth explaining

- React/TypeScript responsive UI; FastAPI/Pydantic validation; transactional SQLite persistence.
- Gemini model discovery, structured response validation and bounded fallback. Actual model identity is displayed for successful calls.
- Integer-cent financial calculations, explicit projection assumptions, no AI-generated balances.
- Separate planned/confirmed states, repeat-safe confirmation, reversible decisions and recoverable profile replacement.
- Category proposals require user approval; stale changes are rejected atomically.
- Manual workflows remain usable when AI is unavailable.

## Verified evidence

On September 26, 2026: 45 backend tests and 9 browser journeys passed, along with Ruff, ESLint, TypeScript and the production build. Browser coverage includes onboarding, editing/persistence, CSV duplicates, purchase comparisons, reminders, archiving, savings corrections, restore recovery, category approval and 320/390-pixel layouts. Live Gemini image understanding succeeded using gemini-3.1-flash-lite on a synthetic cart. Screenshots in `docs/` use synthetic test profiles.

## Explain the scope accurately

This release is local and single-person. It does not connect to banks, transfer money, cancel services, verify retailer prices or send push notifications. Goal dates illustrate a contribution-based projection, not an investment forecast. A public multi-user service would be a separate deployment scope.

Competition placement depends on the judging rubric and other entries; demonstrate the product's working decision loop and evidence rather than claiming a guaranteed outcome.
